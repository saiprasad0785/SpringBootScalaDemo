package com.scala.demo
import org.springframework.boot.SpringApplication

object Application extends App {
  SpringApplication.run(classOf[AppStarter]);
}

