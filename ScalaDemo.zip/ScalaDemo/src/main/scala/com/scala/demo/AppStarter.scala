package com.scala.demo
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class AppStarter {
  
}